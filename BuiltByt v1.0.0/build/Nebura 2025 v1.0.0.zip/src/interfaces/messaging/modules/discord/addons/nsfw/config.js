"use strict";
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="cb7f2a37-ab4e-5196-bcea-500f54b9f7d2")}catch(e){}}();

Object.defineProperty(exports, "__esModule", { value: true });
const config = {
    enabled: false,
    url: "https://api.waifu.pics/nsfw/",
    path: "config/logs-apps/nsfw-image",
    time: 120000
};
exports.default = config;
//# sourceMappingURL=config.js.map
//# debugId=cb7f2a37-ab4e-5196-bcea-500f54b9f7d2
