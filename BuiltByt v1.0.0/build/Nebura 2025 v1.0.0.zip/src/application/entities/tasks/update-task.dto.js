"use strict";
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="531f3985-4e85-5d3e-93ff-b9fba0620c48")}catch(e){}}();

Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateTaskDto = void 0;
class UpdateTaskDto {
    title;
    description;
    dueDate;
    status;
    priority;
    tags;
    reminder;
    recurrence;
    autoDelete;
}
exports.UpdateTaskDto = UpdateTaskDto;
//# sourceMappingURL=update-task.dto.js.map
//# debugId=531f3985-4e85-5d3e-93ff-b9fba0620c48
