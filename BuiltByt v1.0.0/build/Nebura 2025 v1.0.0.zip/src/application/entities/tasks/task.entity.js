"use strict";
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="7c3912df-5bda-5ce3-9020-cf8f4864859d")}catch(e){}}();

Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=task.entity.js.map
//# debugId=7c3912df-5bda-5ce3-9020-cf8f4864859d
