"use strict";
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1fc24d09-26f4-52f3-8832-76471b58f91f")}catch(e){}}();

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logWithLabel = logWithLabel;
const chalk_1 = __importDefault(require("chalk"));
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
const node_1 = __importDefault(require("@sentry/node"));
const winston_1 = require("../winston");
const config_1 = require("../config");
/**
 * A mapping of log labels to their corresponding colors.
 * Each label is associated with a specific color for better visual distinction in logs.
 */
const labelColors = {
    error: chalk_1.default.redBright, // Bright red for error messages.
    success: chalk_1.default.greenBright, // Bright green for success messages.
    debug: chalk_1.default.magentaBright, // Bright magenta for debug messages.
    info: chalk_1.default.blueBright, // Bright blue for informational messages.
    maintenance: chalk_1.default.hex("#FFA500"), // Orange for maintenance messages.
    warn: chalk_1.default.yellowBright, // Bright yellow for warning messages.
    cache: chalk_1.default.hex("#5c143b"), // Custom dark purple for cache messages.
    api: chalk_1.default.hex("#FFA500"), // Orange for API-related messages.
    IPBlocker: chalk_1.default.hex("#FFA500"), // Orange for IP blocker messages.
    LicenseIP: chalk_1.default.hex("#FFA500"), // Orange for license IP messages.
    cluster: chalk_1.default.hex("#EB5C2D"), // Custom orange-red for cluster messages.
};
/**
 * A mapping of log labels to their corresponding display names.
 * These names are used as prefixes in log messages for better readability.
 */
const labelNames = {
    error: "Error", // Display name for error messages.
    success: "Success", // Display name for success messages.
    debug: "Debug", // Display name for debug messages.
    info: "Info", // Display name for informational messages.
    maintenance: "Maintenance", // Display name for maintenance messages.
    warn: "Warn", // Display name for warning messages.
    cache: "Cache", // Display name for cache messages.
    IPBlocker: "IP", // Display name for IP blocker messages.
    api: "API", // Display name for API-related messages.
    LicenseIP: "License", // Display name for license IP messages.
    cluster: "Cluster", // Display name for cluster messages.
};
const logger = new winston_1.WinstonLogger();
// Constants for consistent formatting
const LABEL_WIDTH = 12;
const ORIGIN_WIDTH = 20;
const TIME_WIDTH = 24;
/**
 * Logs a message with a specific label and additional context or error information.
 *
 * This function formats the log output with consistent widths for labels, origins, and timestamps.
 * It also integrates with Winston for structured logging and Sentry for error tracking.
 *
 * @param level - The log level or label. Can be a predefined label, "debug", "verbose", "warning", or "custom".
 * @param message - The main log message to display.
 * @param options - Optional parameters for additional context or error information.
 * @param options.customLabel - A custom label to use when the level is "custom".
 * @param options.context - Additional context data to include in the log. Only displayed in development mode.
 * @param options.error - An error object to include in the log. Its stack trace will be displayed if available.
 *
 * @throws {Error} If the level is "custom" and no custom label is provided.
 */
async function logWithLabel(level, message, options) {
    // Validación de parámetros
    if (level === "custom" && !options?.customLabel) {
        throw new Error("Custom label name must be provided when using custom level.");
    }
    // Configuración de etiquetas
    const labelName = level === "custom" ? options.customLabel : labelNames[level];
    const labelColor = level === "custom" ? chalk_1.default.hex("#5c143b") : labelColors[level];
    // Obtener información del sistema
    const hostname = os_1.default.hostname();
    const pid = process.pid;
    const appVersion = config_1.config.project.version;
    // Obtener origen del log
    const origin = getLogOrigin();
    const time = new Date().toISOString();
    // Format components with consistent widths
    const formattedLabel = labelColor(labelName.padEnd(LABEL_WIDTH, " "));
    const formattedAppInfo = chalk_1.default.hex("#ffffbf")(`${config_1.config.project.name}@${appVersion}`.padEnd(20, " "));
    const formattedHost = chalk_1.default.grey(`[${hostname}:${pid}]`.padEnd(15, " "));
    // Truncate or pad the origin for consistent width
    let formattedOrigin = origin;
    if (origin.length > ORIGIN_WIDTH) {
        const ext = path_1.default.extname(origin);
        const basename = path_1.default.basename(origin, ext);
        const truncatedBasename = basename.substring(0, ORIGIN_WIDTH - ext.length - 3) + "...";
        formattedOrigin = chalk_1.default.grey(`${truncatedBasename}${ext}`.padEnd(ORIGIN_WIDTH, " "));
    }
    else {
        formattedOrigin = chalk_1.default.grey(origin.padEnd(ORIGIN_WIDTH, " "));
    }
    const formattedTime = chalk_1.default.hex("#386ce9")(`[${time}]`.padEnd(TIME_WIDTH, " "));
    // Build the main log line
    const mainLineParts = [
        `${formattedLabel}→`, // Arrow after label
        formattedAppInfo,
        formattedHost,
        formattedOrigin,
        `${formattedTime}\n`,
        message,
    ];
    console.log(mainLineParts.join(" "));
    /**
     * Logs additional context data if provided and the environment is set to "development".
     * The context is formatted as a JSON string and indented for readability.
     */
    if (process.env.NODE_ENV === "development" && options?.context) {
        const contextStr = JSON.stringify(options.context, null, 2)
            .split("\n")
            .map((line) => `  ${line}`)
            .join("\n");
        console.log(chalk_1.default.hex("#2aa198")(`  Context:\n${contextStr}`));
    }
    /**
     * Logs the stack trace of an error if provided. The stack trace is indented for readability.
     * If no stack trace is available, a default message is displayed.
     */
    if (options?.error) {
        const errorStack = options.error.stack
            ?.split("\n")
            .map((line) => `  ${line}`)
            .join("\n") || "No stack available";
        console.log(chalk_1.default.red(`  Error Stack:\n${errorStack}`));
    }
    // Winston logging
    logger.info(message, level === "custom" ? options.customLabel : labelName);
    // Sentry integration for errors
    if (level === "error") {
        node_1.default.withScope((scope) => {
            if (options?.context) {
                scope.setExtras(options.context);
            }
            if (options?.error) {
                scope.setExtra("stack", options.error.stack);
            }
            node_1.default.captureException(options?.error || new Error(message));
        });
    }
}
/**
 * Retrieves the origin file path of the log call.
 *
 * This function analyzes the stack trace to determine the file and line number where the log function was called.
 * It skips frames related to the logger itself and attempts to return a relative path from the project root.
 *
 * @returns {string} The relative file path of the log origin, or "unknown" if it cannot be determined.
 */
const getLogOrigin = () => {
    try {
        const originalPrepare = Error.prepareStackTrace;
        Error.prepareStackTrace = (_, stack) => stack;
        const err = new Error();
        const stack = err.stack;
        Error.prepareStackTrace = originalPrepare;
        if (!Array.isArray(stack))
            return "unknown";
        // Skip frames from this file and logger-related files
        const currentFile = __filename;
        const loggerFiles = ["logger", "log", "winston"]; // Add other logger-related keywords if needed
        for (const frame of stack.slice(1)) {
            const fileName = frame.getFileName();
            if (!fileName)
                continue;
            const isLoggerFile = loggerFiles.some((keyword) => fileName.toLowerCase().includes(keyword));
            if (fileName !== currentFile && !isLoggerFile) {
                // Return relative path from project root if possible
                const projectRoot = path_1.default.join(__dirname, "../../");
                const relativePath = path_1.default.relative(projectRoot, fileName);
                return relativePath || path_1.default.basename(fileName);
            }
        }
        return "unknown";
    }
    catch {
        return "unknown";
    }
};
//# sourceMappingURL=console.js.map
//# debugId=1fc24d09-26f4-52f3-8832-76471b58f91f
