const config = {
  enabled: false,
  url: "https://api.waifu.pics/nsfw/",
  path: "config/logs-apps/nsfw-image",
  time: 120000
}

export default config;