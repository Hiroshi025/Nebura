# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.0.15](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.16...v0.0.15) (2025-06-27)

### [0.0.14](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.16...v0.0.14) (2025-06-25)

### [0.0.13](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.16...v0.0.13) (2025-06-21)

### [0.0.12](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.16...v0.0.12) (2025-06-20)

### [0.0.11](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.16...v0.0.11) (2025-06-17)

### [0.0.10](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.16...v0.0.10) (2025-06-06)

### [0.0.16](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.15...v0.0.16) (2025-05-02)

### [0.0.15](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.14...v0.0.15) (2025-05-01)

### [0.0.14](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.13...v0.0.14) (2025-05-01)

### [0.0.13](https://github.com/Hiroshi025/Nebura-AI/compare/v0.0.12...v0.0.13) (2025-04-25)


### Bug Fixes

* Update Discord Client ([bc46690](https://github.com/Hiroshi025/Nebura-AI/commit/bc46690a8a41bfd61ab21e76692a1b5bf65844a7))
